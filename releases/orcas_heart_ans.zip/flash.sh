dfu-programmer at32uc3b0256 erase
dfu-programmer at32uc3b0256 flash orcas_heart_ans.hex --suppress-bootloader-mem
dfu-programmer at32uc3b0256 start
