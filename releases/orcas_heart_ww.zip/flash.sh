dfu-programmer at32uc3b0256 erase
dfu-programmer at32uc3b0256 flash orcas_heart_ww.hex --suppress-bootloader-mem
dfu-programmer at32uc3b0256 start
